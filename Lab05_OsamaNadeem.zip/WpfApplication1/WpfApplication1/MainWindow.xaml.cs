﻿/* Name: Osama Nadeem (120672)
   Class: BSCS - 5c
   Lab: 05
  
   GitHub link: https://github.com/OsamaNadeeem/lab05 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApplication1
{
    public partial class MainWindow : Window
    {
        int ctr = 0;     
        public MainWindow()
        {
            InitializeComponent();
            
        }

        private void count_Click(object sender, RoutedEventArgs e)
        {
            ctr++; //increment a number when count button is clicked                 
            num.Text = ctr.ToString(); //print the incremented number in the text box
        }

        private void reset_Click(object sender, RoutedEventArgs e)
        {
            ctr = 0;   //reset the number to 0 when reset button is clicked
            num.Text = ctr.ToString(); //print the number (0) in the text box
        }

        private void quit_Click(object sender, RoutedEventArgs e)
        {
            this.Close(); //close the application when quit button is clicked
        }

     
    }
}
